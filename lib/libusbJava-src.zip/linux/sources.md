
Source code for libusbJava :  
https://salsa.debian.org/java-team/libusb-java  

Java headers :  
https://github.com/openjdk/jdk/blob/jdk-11+28/src/java.base/share/native/include/jni.h
https://github.com/openjdk/jdk/blob/jdk-11+28/src/java.base/unix/native/include/jni_md.h

Dependencies :
https://github.com/libusb/libusb-compat-0.1/blob/master/libusb/usb.h
https://pkgs.org/download/libusb-compat
